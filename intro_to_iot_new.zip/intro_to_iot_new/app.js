var express 	= require('express'), //exp mannages route requests & views to server
	bodyParser  = require('body-parser'), //body parser looks into body of a request
	app			= express();

var indexRoutes = require('./routes/index'); //get web-page routes
	apiRoutes   = require('./routes/api'); //get api routes

app.set('port', (process.env.PORT || 3000)) //access port
app.set('view engine', 'ejs'); //ejs allows generating html w/ js
app.use(express.static(__dirname + '/assets')); //look for files included in ejs files in /assets
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true})); //configures body parser

/******** ROUTES ********/
app.use('/', indexRoutes); //use routes
app.use('/api', apiRoutes); //api routes always have /api in front

app.listen(app.get('port'), () => console.log('Listening on port ' + app.get('port')));