var express			= require('express'), //manage routes and views
	router			= express.Router(),
	db				= require('../models'), //get prev data models
	//helpers
	dataHelpers 	= require('../helpers/data'),
	statsHelpers 	= require('../helpers/stats'),
	settingsHelpers = require('../helpers/settings');
	ambianceSettingsHelpers = require('../helpers/ambianceSettings');

/******** sensor readings ********/
//ROUTES
/*
 * C - CREATE
 * R - READ
 * U - UPDATE
 * D - DELETE
*/
//data route
router.route('/data')
	.get(dataHelpers.getData) //retrieve data
	.post(dataHelpers.createData) //create data
	.delete(dataHelpers.deleteData); //delete data to reset like if in new time-zone

//one data element route
router.route('/data/:id')
	.get(dataHelpers.getOneData) //retrieve one data
	.put(dataHelpers.editData) //edit data
	.delete(dataHelpers.deleteOneData); //delete one data

router.route('/settings')
	.get(settingsHelpers.getSettings) //retrieve settings
	.put(settingsHelpers.editSettings); //edit settings

router.route('/statistics')
	.get(statsHelpers.getStats) //retrieve stats
	.put(statsHelpers.editStats) //edit stats
	.delete(statsHelpers.resetStats); //delete stats

router.route('/ambianceSettings')
	.get(ambianceSettingsHelpers.getAmbianceSettings) //retrieve ambiance
	.put(ambianceSettingsHelpers.editAmbianceSettings); //edit ambiance

module.exports = router;