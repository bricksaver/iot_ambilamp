var express		= require('express'),
	db          = require('../models'),
	router		= express.Router();

// home route
router.get('/', (req, res) => {
	var setting;
	//render prev. stored color on home template
	db.Settings.findOne({}) //get entry from Settings collection in database
	.then( function(result) { //once result obtained...
		//console.log('settings found');
		setting = result;
		return db.Stats.findOne({}) //get entry from Stats collection in database
	})
	.then( function(statResult) {
		//console.log('stats found');
		//create stats object based on form input and limit avg temp & humidity to 2 sig figs
		var timeInHot = statResult.timeInHot/statResult.timeTotal;
		var timeInCold = statResult.timeInCold/statResult.timeTotal;
		var timeInHumid = statResult.timeInHumid/statResult.timeTotal;
		var timeInDry = statResult.timeInDry/statResult.timeTotal;
		var timeOn = statResult.timeOn/statResult.timeTotal;        //AFTER SEEDING, NOT GETTING SETTING/STATS READ TO CONSOLE AS EMPTY

		var stats = {
			avgTemperature: statResult.avgTemperature.toFixed(2),
			avgHumidity: statResult.avgHumidity.toFixed(2),
			avgBrightness: statResult.avgBrightness,
			temperatureData: [timeInHot, 1-timeInHot-timeInCold, timeInCold],
			humidityData: [timeInHumid, 1-timeInHumid-timeInDry, timeInDry],
			onData: [timeOn, 1-timeOn]
		};

		//console.log("obtained from home route: " + setting);
		//console.log("obtained from home route: " + stats);

		res.render('home', {settings: setting, stats: stats}); //render home html with prev. settings/stats found
	})
	.catch( function(err) {
		res.send(err);
	});
});

// details route
router.get('/details', (req, res) => {
	db.Data.find({}).limit(24).sort({timestamp: -1}) //get up to 24 readings, '-1' for reverse chronological order
	.then( function(data) {
		var times = [];
		var temperatures = [];
		var humidities = [];
		var brightnesses = [];

		data.forEach( function(reading) {
			times.push("'" + reading.timestamp + "'");
			temperatures.push(reading.temperature);
			humidities.push(reading.humidity);
			brightnesses.push(reading.brightness);
		});

		res.render('details', {data: data,
							   temperature: temperatures.reverse(),
							   humidity: humidities.reverse(),
							   brightness: brightnesses.reverse(),
							   times: times.reverse()
		});
	})
	.catch( function(err) {
		res.send(error);
	});
});

// ambiance route
router.get('/ambiance', (req, res) => {
	var ambianceSetting;
	//render prev. stored ambiance colors on ambiance template
	db.AmbianceSettings.findOne({}) //get entry from BeatOptions collection in database
	.then( function(result) { //once result obtained...
		//console.log('ambianceSettings found');
		ambianceSetting = result;

		//check if user clicked begin-transitioning or listen-for-beat and run accordingly
		var numberOfItems = 35;
		var gradientColor = new Array(numberOfItems);
		if (ambianceSetting.lightIsTransitioning == true) { 
			var Rainbow = require('rainbowvis.js');
			var rainbow = new Rainbow(); 
			rainbow.setNumberRange(1, numberOfItems);
			rainbow.setSpectrum(ambianceSetting.lightColor1, ambianceSetting.lightColor2, ambianceSetting.lightColor3, ambianceSetting.lightColor4, ambianceSetting.lightColor1);
			for (var i = 1; i < numberOfItems; i++) {
			  	gradientColor[i-1] = rainbow.colourAt(i).toUpperCase();
			}
		} 
		else {
			for(i=0; i < numberOfItems; i++) {
				gradientColor[i] = '000000';
			}
		}

		var ambianceSettingNew = {
			'lightColor1': ambianceSetting.lightColor1,
			'lightColor2': ambianceSetting.lightColor2,
			'lightColor3': ambianceSetting.lightColor3,
			'lightColor4': ambianceSetting.lightColor4,
			'lightIsTransitioning': ambianceSetting.lightIsTransitioning,
			'disableBlinking': ambianceSetting.disableBlinking,
			'lightIsOff': ambianceSetting.lightIsOff,
			'gradientColor1': gradientColor[0],
			'gradientColor2': gradientColor[1],
			'gradientColor3': gradientColor[2],
			'gradientColor4': gradientColor[3],
			'gradientColor5': gradientColor[4],
			'gradientColor6': gradientColor[5],
			'gradientColor7': gradientColor[6],
			'gradientColor8': gradientColor[7],
			'gradientColor9': gradientColor[8],
			'gradientColor10': gradientColor[9],
			'gradientColor11': gradientColor[10],
			'gradientColor12': gradientColor[11],
			'gradientColor13': gradientColor[12],
			'gradientColor14': gradientColor[13],
			'gradientColor15': gradientColor[14],
			'gradientColor16': gradientColor[15],
			'gradientColor17': gradientColor[16],
			'gradientColor18': gradientColor[17],
			'gradientColor19': gradientColor[18],
			'gradientColor20': gradientColor[19],
			'gradientColor21': gradientColor[20],
			'gradientColor22': gradientColor[21],
			'gradientColor23': gradientColor[22],
			'gradientColor24': gradientColor[23],
			'gradientColor25': gradientColor[24],
			'gradientColor26': gradientColor[25],
			'gradientColor27': gradientColor[26],
			'gradientColor28': gradientColor[27],
			'gradientColor29': gradientColor[28],
			'gradientColor30': gradientColor[29],
			'gradientColor31': gradientColor[30],
			'gradientColor32': gradientColor[31],
			'gradientColor33': gradientColor[32],
			'gradientColor34': gradientColor[33],
			'gradientColor35': gradientColor[34]
		}
		res.render('ambiance', {ambianceSettings: ambianceSettingNew}); //render ambiance html with prev. ambianceSettings found
		return db.AmbianceSettings.findOneAndUpdate({}, ambianceSettingNew, {'new': true, upsert: true})
	})
	.then( function(edited) {
		console.log(edited); //log new settings
	}) 
	.catch( function(err) {
		res.send(err);
	});
	//res.render('beat', {ambianceSettings: ambianceSetting}); //render ambiance html with prev. ambianceSettings found
});

// set-color route
router.post('/set-color', (req, res) => {
	//from the start here, already have settings input submitted
	db.Settings.findOne({}) //get entry from Settings collection in db for prev. settings
	.then( function(result) { //use result to...
		//create setting object based on form input
		var setting = {
			'lightColor': req.body.color,
			'lightIsOn': true,
			'disableBlinking': false
		}
		//logic for setting database setting values dependent on retrieved user input
		if (req.body.color == '000000') {
			setting['lightColor'] = '000000';
			setting['lightIsOn'] = false;
			setting['disableBlinking'] = false;
		}
		if (req.body.options) {
			if (req.body.options.setAsDefault) {
				setting['defaultColor'] = req.body.color;
			} else if (req.body.options.changeToDefault) {
				setting['lightColor'] = result['defaultColor'];
				setting['lightIsOn'] = true;
			} else if (req.body.options.disableBlinking) {
				setting['disableBlinking'] = true;
			} else if (req.body.options.turnOff) {
				setting['lightColor'] = '000000';
				setting['lightIsOn'] = false;
				setting['disableBlinking'] = false;
			}
		}

		//update entry in Settings collection in database
		return db.Settings.findOneAndUpdate({}, setting, {'new': true, upsert: true})
	})
	.then( function(edited) {
		console.log(edited); //log new settings
		res.redirect('/');
	}) 
	.catch( function(err) {
		res.send(err); //send mssg of errors
	});
});

// set-ambiance-colors-and-settings route
router.post('/set-ambiance-colors-and-settings', (req, res) => {
	//from the start here, already have ambianceSettings input submitted
	db.AmbianceSettings.findOne({}) //get entry from ambianceSettings collection in db for prev. ambianceSettings
	.then( function(result) { //use result to...
		//create ambianceSetting object based on form input
		var ambianceSetting = {
			'lightColor1': req.body.ambianceColor1,
			'lightColor2': req.body.ambianceColor2,
			'lightColor3': req.body.ambianceColor3,
			'lightColor4': req.body.ambianceColor4,
			'lightIsTransitioning': result['lightIsTransitioning'],
			'disableBlinking': false,
			'lightIsOff': false
		}
		//logic for ambianceSettings database ambianceSettings values dependent on retrieved user input
		if (req.body.ambianceColor1 == '000000' && req.body.ambianceColor2 == '000000' && req.body.ambianceColor3 == '000000' && req.body.ambianceColor4 == '000000') {
			ambianceSetting['lightColor1'] = '000000';
			ambianceSetting['lightColor2'] = '000000';
			ambianceSetting['lightColor3'] = '000000';
			ambianceSetting['lightColor4'] = '000000';
			ambianceSetting['lightIsTransitioning'] = false;
			ambianceSetting['disableBlinking'] = false; //false means not enabled
			ambianceSetting['lightIsOff'] = true;
		}
		if (req.body.ambianceSettings) {
			//console.log('inside ambiance settings');
			if (req.body.ambianceSettings.beginTransitioning) {
				ambianceSetting['lightIsTransitioning'] = true;
				ambianceSetting['disableBlinking'] = false;
			} else if (req.body.ambianceSettings.disableBlinking) {
				ambianceSetting['disableBlinking'] = true;
			} else if (req.body.ambianceSettings.turnOff) {
				ambianceSetting['lightColor1'] = '000000';
				ambianceSetting['lightColor2'] = '000000';
				ambianceSetting['lightColor3'] = '000000';
				ambianceSetting['lightColor4'] = '000000';
				ambianceSetting['lightIsTransitioning'] = false;
				ambianceSetting['disableBlinking'] = false; //false means not enabled
				ambianceSetting['lightIsOff'] = true;
			}
		}
		//update entry in AmbianceSettings collection in database
		return db.AmbianceSettings.findOneAndUpdate({}, ambianceSetting, {'new': true, upsert: true})
	})
	.then( function(edited) {
		res.redirect('/ambiance');
	}) 
	.catch( function(err) {
		res.send(err); //send mssg of errors
	});
});

// set-hot, cold, dry, humid, dark configurations route
router.post('/configure', (req, res) => {
	//from the start here, already have configurations input submitted
	//update entry in Settings collection in database with setting var from home.ejs
	db.Settings.findOneAndUpdate({}, req.body.setting, {'new': true, upsert: true})
	.then( function(edited) {
		console.log(edited);
		res.redirect('/');
	})
	.catch( function(err) {
		res.send(err);
	});
});

/*

//Testing Details Data Plots with artificial seeded data
router.get('/seed/:temp/:hum/:bright', (req, res) => { //get seed data from browser
	var seed = {
		//access entries from browser
		temperature: req.params.temp,
		humidity: req.params.hum,
		brightness: req.params.bright
	}
	//create seed
	db.Data.create(seed)
	.then( function(newData) {
		res.redirect('/details');
	})
	.catch( function(err) {
		res.send(err);
	})
})

//Testing Dashboard Stats Plots with artificial seeded data
router.get('/seedStats', (req, res) => {
	var seed = {
		avgTemperature: 32,
		avgHumidity: 11,
		avgBrightness: 721,
		timeInHot: 20,
		timeInCold: 60,
		timeInDry: 80,
		timeInHumid: 8,
		timeOn: 59,
		timeTotal: 100
	}
	//update entry in Stats collection in database with seed var
	db.Stats.findOneAndUpdate({}, seed, {'new': true, upsert: true})
	.then( function(stats) {
		//console.log("seed updated: " + stats);
		res.redirect('/');
	})
	.catch( function(err) {
		res.send(err);
	})
});
*/
//Testing ambiance route with artificial seeded data
router.get('/seedAmbianceSettings', (req, res) => {
	var seed = {
		'lightColor1': '444444',
		'lightColor2': '444444',
		'lightColor3': '444444',
		'lightColor4': '444444',
		'lightIsTransitioning': true,
		'disableBlinking': false,
		'lightIsOff': false,
		'gradientColor1': '000000',
		'gradientColor2': '000000',
		'gradientColor3': '000000',
		'gradientColor4': '000000',
		'gradientColor5': '000000',
		'gradientColor7': '000000',
		'gradientColor8': '000000',
		'gradientColor9': '000000',
		'gradientColor10': '000000',
		'gradientColor11': '000000',
		'gradientColor12': '000000',
		'gradientColor13': '000000',
		'gradientColor14': '000000',
		'gradientColor15': '000000',
		'gradientColor16': '000000',
		'gradientColor17': '000000',
		'gradientColor18': '000000',
		'gradientColor19': '000000',
		'gradientColor20': '000000',
		'gradientColor21': '000000',
		'gradientColor22': '000000',
		'gradientColor23': '000000',
		'gradientColor24': '000000',
		'gradientColor25': '000000',
		'gradientColor26': '000000',
		'gradientColor27': '000000',
		'gradientColor28': '000000',
		'gradientColor29': '000000',
		'gradientColor30': '000000',
		'gradientColor31': '000000',
		'gradientColor32': '000000',
		'gradientColor33': '000000',
		'gradientColor34': '000000'
	}
	//update entry in AmbianceSettings collection in database with seed var
	db.AmbianceSettings.findOneAndUpdate({}, seed, {'new': true, upsert: true})
	.then( function(ambianceSettings) {
		//console.log("ambianceSettings updated");
		res.redirect('/ambiance');
	})
	.catch( function(err) {
		res.send(err);
	})
});



//make routes available to app
module.exports = router;