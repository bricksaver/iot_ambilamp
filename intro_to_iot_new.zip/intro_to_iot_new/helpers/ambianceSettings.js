
var db = require('../models');

//get AmbianceSettings data
exports.getAmbianceSettings = function(req, res) {
	db.AmbianceSettings.findOne({})
	.then( function(ambianceSettings) {
		res.json(ambianceSettings);
	})
	.catch( function(err) {
		res.send(err);
	});
}

//edit AmbianceSettings data
exports.editAmbianceSettings = function(req, res) {
	db.AmbianceSettings.findOneAndUpdate({}, req.body, {'new': true, upsert: true})
	.then( function(editedAmbianceSettings) {
		res.json(editedAmbianceSettings);
	})
	.catch( function(err) {
		res.send(err);
	});
}
