//get data models
var db = require('../models');

//get api Data data
exports.getData = function(req, res) {
	db.Data.find() //get all entries from Data collection in database
	.then( function(data) {
		res.json(data); //format data in json format to send
	})
	.catch( function(err) {
		res.send(err);
	})
}

//create api Data data
exports.createData = function(req, res) {
	db.Data.create(req.body) //create new data
	.then( function(newData) {
		res.json(newData);
	})
	.catch( function(err) {
		res.send(err);
	});
}

//delete api Data data
exports.deleteData = function(req, res) {
	db.Data.remove({}) //delete all data
	.then( function() {
		res.json({ message: 'Data wiped'})
	})
	.catch( function(err) {
		res.send(err);
	});
}

//get one api Data data
exports.getOneData = function(req, res) {
	db.Data.findById(req.params.id)
	.then( function(foundData) {
		res.json(foundData);
	})
	.catch( function(err) {
		res.send(err);
	});
}

//edit api Data data
exports.editData = function(req, res) {
	//update entry in Data collection in database with req.body var from api.js
	db.Data.findOneAndUpdate({ _id: req.params.id}, req.body, {'new': true, upsert: true})
	.then( function(editedData) {
		res.json(editedData);
	})
	.catch( function(err) {
		res.send(err);
	});
}

//delete one api Data data
exports.deleteOneData = function(req, res) {
	db.Data.remove( { _id: req.params.id})
	.then( function(foundData) {
		res.json( {message: 'Sucessfully deleted'});
	})
	.catch( function(err) {
		res.send(err);
	});
}