//INDEX cause used in both home & details & ambiance pages for example

// Set Navbar item to be blue when hovered over or clicked
// note: function gets called in individual page js files
function setActivePage(page_id) {
	var items = document.querySelector('navbar').children; //look for navbar tag in page that calls function and return children as array

	for (i = 1; i < items.length; i++) {
		items[i].classList.remove('active');
	}

	document.getElementById(page_id).classList.add('active');
}