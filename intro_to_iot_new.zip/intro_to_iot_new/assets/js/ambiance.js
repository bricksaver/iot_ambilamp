//sets navbar ambiance item as blue when selected or hovered over
setActivePage('nav_ambiance');

//disable begin-transitioning, disable-blinking, and turn-off buttons when 'off' colors set
if (document.querySelector('.js1').value == '000000' && document.querySelector('.js2').value == '000000' && document.querySelector('.js3').value == '000000' && document.querySelector('.js4').value == '000000') {
	document.getElementById('begin-transitioning-button').classList.add('disabled')
	document.getElementById('disable-blinking-button').classList.add('disabled')
	document.getElementById('turn-off-button').classList.add('disabled')
} else {
	document.getElementById('begin-transitioning-button').classList.remove('disabled')
	//only allow disable-blinking-button and turn-off button to be enabled when light is transitioning
	if (document.querySelector('.lightIsTransitioningValue').value == 'false') {
		document.getElementById('disable-blinking-button').classList.add('disabled')
		document.getElementById('turn-off-button').classList.remove('disabled')
	}
}

//function to submit ambiance settings
function submit(beginTransitioning=false, disableBlinking=false, turnOff=false) {
	if (beginTransitioning) {
		document.getElementById('begin-transitioning').checked = true;
	}

	if (disableBlinking) {
		document.getElementById('disable-blinking').checked = true;
	}

	if (turnOff) {
		document.getElementById('turn-off').checked = true;
	}

	//submit selected ambiance settings to set-color route
	document.getElementById('color-form').submit(); //submit to be found by req in routes
}