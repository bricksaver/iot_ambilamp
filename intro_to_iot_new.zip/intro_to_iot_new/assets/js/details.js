var labels = [];
//sets navbar details item as blue when selected or hovered over
setActivePage('nav_details');
//auto-clicks to convert data time to local time
document.getElementById('convert-times').click();
//auto-clicks temp chart when run so temp graph displays on app loading
document.getElementById('first-chart').click();

tableRows = document.querySelectorAll('.date');
tableRows.forEach( function(row, i) {
	row.innerHTML = labels[i];
});

//convert History Timestamps to Local Time
function convertTimes(times) {
	for (i=0; i < times.length; i++) {
		var date = new Date(times[i]);
		labels[i] = date.toLocaleString();
	}
}

//sets 'active' graph tab names as bolded
function showLineChart(elem, data) { 
	//removes old graphs to prevent diff. graphs stacking on other graphs
	var oldCtx = document.querySelector('canvas'); //ctx = <canvas> in details.ejs
	var parent = oldCtx.parentNode;
	parent.removeChild(oldCtx); //gets rid of canvas so nothing can be drawn at all
	//create new canvas
	var ctx = document.createElement('canvas');
	ctx.height = 275;

	parent.appendChild(ctx);
	//rm old 'active' tab and add new 'active' tab
	var items = elem.parentNode.children;
	for (i = 0; i < items.length; i++) {
		items[i].classList.remove('active');
	}
	elem.classList.add('active');

	//ctx = <canvas> in details.ejs
	var ctx = document.querySelector('canvas');
	renderChart(ctx, data);
}

//temp, humid, bright graph chart
function renderChart(ctx, data) {
	//fake data
	var data = {
		datasets: [{
			data: data
		}],
		labels: labels
	};
	//plot graph chart
	var myLineChart = new Chart(ctx, {
	    type: 'line',
	    data: data,
	    options: {
    		legend: {
    			display: false,
    		}
    	}
	});
}