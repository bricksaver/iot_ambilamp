//CREATE DATA MODEL

var mongoose	 = require('mongoose');

//create data schema
var dataSchema = new mongoose.Schema({
	timestamp: {
		type: Date,
		default: Date.now
	},
	temperature: {
		type: Number,
		required: 'Must record temperature'
	},
	humidity: {
		type: Number,
		required: 'Must record humidity'
	},
	brightness: {
		type: Number,
		required: 'Must record brightness'
	}
});

//send out model
var Data = mongoose.model('Data', dataSchema);

module.exports = Data; //export to app