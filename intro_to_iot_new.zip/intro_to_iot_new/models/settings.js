//CREATE SETTINGS MODEL

var mongoose	 = require('mongoose');

//create settings schema
var settingsSchema = new mongoose.Schema({
	defaultColor: {
		type: String
	},
	lightColor: {
		type: String
	},
	disableBlinking: {
		type: Boolean
	},
	lightIsOn: {
		type: Boolean
	},
	hotThreshold: {
		type: Number
	},
	coldThreshold: {
		type: Number
	},
	humidThreshold: {
		type: Number
	},
	dryThreshold: {
		type: Number
	},
	darkThreshold: {
		type: Number
	}
});

//send out model
var Settings = mongoose.model('Settings', settingsSchema);

module.exports = Settings; //export to app