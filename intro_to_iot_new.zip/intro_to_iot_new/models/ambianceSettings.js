//CREATE BEAT OPTIONS MODEL

var mongoose	 = require('mongoose');

//create beatOptions schema
var ambianceSettingsSchema = new mongoose.Schema({
	lightColor1: {
		type: String
	},
	lightColor2: {
		type: String
	},
	lightColor3: {
		type: String
	},
	lightColor4: {
		type: String
	},
	lightIsTransitioning: {
		type: Boolean
	},
    disableBlinking: {
        type: Boolean
    },
	lightIsOff: {
		type: Boolean
	},
	
    gradientColor1:{type: String},
    gradientColor2:{type: String},
    gradientColor3:{type: String},
    gradientColor4:{type: String},
    gradientColor5:{type: String},
    gradientColor6:{type: String},
    gradientColor7:{type: String},
    gradientColor8:{type: String},
    gradientColor9:{type: String},
    gradientColor10:{type: String},
    gradientColor11:{type: String},
    gradientColor12:{type: String},
    gradientColor13:{type: String},
    gradientColor14:{type: String},
    gradientColor15:{type: String},
    gradientColor16:{type: String},
    gradientColor17:{type: String},
    gradientColor18:{type: String},
    gradientColor19:{type: String},
    gradientColor20:{type: String},
    gradientColor21:{type: String},
    gradientColor22:{type: String},
    gradientColor23:{type: String},
    gradientColor24:{type: String},
    gradientColor25:{type: String},
    gradientColor26:{type: String},
    gradientColor27:{type: String},
    gradientColor28:{type: String},
    gradientColor29:{type: String},
    gradientColor30:{type: String},
    gradientColor31:{type: String},
    gradientColor32:{type: String},
    gradientColor33:{type: String},
    gradientColor34:{type: String},
    gradientColor35:{type: String}
});

//send out model
var AmbianceSettings = mongoose.model('AmbianceSettings', ambianceSettingsSchema);

module.exports = AmbianceSettings; //export to app