//CREATE STATISTICS MODEL

var mongoose	 = require('mongoose');

//create statistics schema
var statsSchema = new mongoose.Schema({
	avgTemperature: {
		type: Number,
	},
	avgHumidity: {
		type: Number
	},
	avgBrightness: {
		type: Number,
	},
	timeInHot: {
		type: Number,
	},
	timeInCold: {
		type: Number,
	},
	timeInDry: {
		type: Number,
	},
	timeInHumid: {
		type: Number,
	},
	timeOn: {
		type: Number,
	},
	timeTotal: {
		type: Number,
		//if you try to insert something w/o timeTotal field filled, returns error mssg
		required: 'You must increment the number of readings'
	}
});

//send out model
var Stats = mongoose.model('Stats', statsSchema);

module.exports = Stats; //export to app