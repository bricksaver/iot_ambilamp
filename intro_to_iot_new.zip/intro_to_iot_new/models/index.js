//CONNECT TO DB AND EXPORTS SETTINGS MODEL

var mongoose	= require('mongoose'), //allows to define db data types in structs
	dotenv		= require('dotenv'); //used to create non-local PORT

dotenv.load();

mongoose.set('debug', true);
mongoose.connect(process.env.DATABASE); //connect to non-local database
//console.log(process.env.DATABASE);
mongoose.promise = Promise; //allows use of mongoose functions

module.exports.Settings = require('./settings'); //export Settings collection in DB w/ settings model
module.exports.Stats	= require('./statistics'); //export Stats collection in DB w/ statistics model
module.exports.Data	    = require('./data'); //export Data collection in DB w/ data model
module.exports.AmbianceSettings = require('./ambianceSettings'); //export AmbianceSettings collection in DB w/ ambianceSettings model